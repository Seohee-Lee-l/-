// 커서를 따라다니는 요소 가져오기
const el=document.querySelector(".followAnimation");

// 마우스 좌표
let mouseX=0;
let mouseY=0;

// 커서를 따라다니는 요소의 좌표
// e.clientX, e.clientY: 현재 마우스 위치 좌표
let currentX=0;
let currentY=0;


// 마우스 이동 시
document.body.addEventListener("mousemove", (event)=> {
    // 마우스 좌표 저장   이벤트가 발생한 위치
    // clientX와 clientY 속성을 사용하여 클릭 이벤트가 발생한 좌표를 얻음

    mouseX=event.clientX;
    mouseY=event.clientY;
});

tick();

function tick() {
    requestAnimationFrame(tick);
    // 애니메이션을 업데이트할 때 호출되는 함수
    // 브라우저에서 애니메이션을 부드럽게 실행하기 위해 사용하는 JavaScript 함수


    currentX+=(mouseX-currentX)*0.1;
    currentY+=(mouseY-currentY)*0.1;
    // 현재 위치(currentX, currentY)를 목표 위치(mouseX, mouseY)에 점점 가까워지도록 업데이트하는 방식
    // 따라오는 요소 좌표에 마우스 좌표를 지연시켜 반영

    el.style.transform=`translate(${currentX}px, ${currentY}px)`;
}