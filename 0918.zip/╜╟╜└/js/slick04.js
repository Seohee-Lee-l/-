$(function() {
    $(".main").slick({
        dots: true,
        autoplay: true,
        infinite: true,
        autoplaySpeed: 2000,
        slidesToShow: 4,
        // 한 화면에 보여줄 아이템 수

        slidesToScroll: 1,
        // 한 번에 스크롤할 아이템 수

        responsive: [
            {
                breakpoint: 1024,
                // 1024px 미만
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                }
            },

            {
                breakpoint: 600,
                // 600px 미만
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },

            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
});