const API_KEY="64ac107f";
const {useState}=React;

function SearchBox({onSearch}) {
  const [query, setQuery]=useState("");

  const handleSearch=()=> {
    // trim: 문자열 양쪽 공백 제거
    if (!query.trim()) {
      alert('영화 제목을 입력하세요!');
      return;
    }
    onSearch(query);
    setQuery("");
    // 검색어 초기화
  }

  // 영화 제목을 입력하고 검색을 실행하는 역할
  return (
    <div className='search-box'>
      <input
        type='text'
        value={query}
        onChange={(e)=> setQuery(e.target.value)}
        placeholder='영화 제목을 입력하세요...'
        onKeyDown={(e)=> e.key==='Enter' && handleSearch()}
      />

      <button onClick={handleSearch}>검색</button>
    </div>
  )
}

function MovieCard({movie}) {
  return (
    <div className='movie'>
      <img
        src={
          movie.Poster!=="N/A" ? movie.Poster : "https://via.placeholder.com/150"
        }
        alt={movie.Title}
      />

      <h3>{movie.Title}</h3>
      <p>{movie.Year}</p>
    </div>
  )
}

// 여러 영화 정보를 한꺼번에 화면에 표시
// movie.imdbID는 OMDB API에서 받은 각 영화의 고유한 ID 값
function MovieList({movies}) {
  if (movies.length===0) {
    return <p className='g'>검색 결과가 없습니다.</p>
  }

  return (
    <div className='movie-container'>
      {movies.map((movie) => (
        <MovieCard key={movie.imdbID} movie={movie}/>
      ))}
    </div>
  )
}

function App() {
  const [movies, setMovies]=useState([]);
  const [loading, setLoading]=useState(false);

  // s: query >> 검색할 영화 제목 전달
  // 성공 시 영화 목록(Search)을 movies 상태에 저장
  const searchMovies=async(query)=> {
    setLoading(true);
    try {
      const response=await axios.get("https://www.omdbapi.com/", {
        params: {apikey: API_KEY, s: query},
      });

      if (response.data.Response==='True') {
        setMovies(response.data.Search);
      } else {
        setMovies([]);
      }
    } catch (error) {
      console.error(error);
      alert('데이터를 불러오는 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
      // 끝나면 로딩 상태 해제
    }
  }
  
  return (
    <div className="App">
      <div className='box'>
        <h1>영화 검색 앱</h1>

        <SearchBox onSearch={searchMovies}/>
      </div>

      {loading ? <p className='g'>로딩 중...</p> : <MovieList movies={movies}/>}
    </div>
  );
}


ReactDOM.render(
  <App/>,
  document.getElementById("root")
);