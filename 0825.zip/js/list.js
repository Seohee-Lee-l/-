const itemList=[];
const addBtn=document.querySelector("#add");
addBtn.addEventListener('click', addList);

function addList() {
    const item=document.querySelector("#item").value;

    if (item!=null) {
        itemList.push(item);
        document.querySelector("#item").value="";
        document.querySelector("#item").focus();
    }
    showList();
};

function showList() {
    let list="<ul>";

    for (let i=0; i<itemList.length; i++) {
        list+=`<li> ${itemList[i]} <span class='close' id="${i}"> X </span></li>`;
        // "<li>" + itemList[i]+"<span class='close' id="+i+">X</span></li>"; 
    }
    list+="</ul>";

    document.querySelector('#itemList').innerHTML=list;
    // list 내용 표시

    const remove=document.querySelectorAll('.close');
    for (let i=0; i<remove.length; i++) {
        remove[i].addEventListener('click', removeList);
    }
};

function removeList() {
    const id=this.getAttribute("id");
    itemList.splice(id, 1);
    // id부터 1개 삭제

    showList();
    // 삭제한 걸 제외하고 다시 배열 돌려야 하니까 호출
};