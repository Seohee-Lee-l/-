const slides=document.querySelectorAll("#container > img");
const prev=document.querySelector("#prev");
const next=document.querySelector("#next");

let current=0;
// 표시할 이미지 위치

showSlide(current);
// showSlide() 함수를 실행해 current 위치의 이미지 표시

prev.onclick=prevSlide;
next.onclick=nextSlide;
// 함수 실행

function showSlide(n) {
    for (let i=0; i<slides.length; i++) {
        slides[i].style.display='none';
    }
    slides[n].style.display='block';
    // n번째 이미지를 화면에 표시
};

function prevSlide() {
    if (current>0) current-=1;
    else current=slides.length-1;
    showSlide(current);
};

function nextSlide() {
    if (current<slides.length-1) current+=1;
    else current=0;
    showSlide(current);
};