let min, sec;
let timer;
// setIntercal() 결과를 저장할 변수

function startTimer() {
    min=document.querySelector('#startMin').value;
    if (min=="") min=0;

    sec=document.querySelector("#startSec").value;
    if (sec=="") sec=0;

    timer=setInterval(countTimer, 1000);
    // setInterval(작업, 시간)
};

function countTimer() {
    if (sec!=0) {
        sec--;
        document.querySelector('#display').innerText=
        `${min}분 ${sec}초 남았습니다.`;
        // min + "분" + sec + "초 남았습니다.";
    } else {
        if (min!=0) {
            min--;
            sec=59;
        } else {
            clearTimer(timer);
            document.querySelector("#display").innerText=`타이머 종료`;
        }
    }
};

function resetTimer() {
    clearTimer(timer);
};

function clearTimer(t) {
    clearInterval(t);
    // 타이머 종료

    document.querySelector('#display').innerText="";
    // 표시 내용 지우기
    document.querySelector("#startMin").value="";
    // 사용자 입력 내용 (분) 지우기
    document.querySelector("#startSec").value="";
    // 사용자 입력 내용 (초) 지우기
};