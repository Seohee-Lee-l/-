$(function() {
    const listHeight=$("#page").height();
    $("ul").append("<p>Height : "+listHeight+"px</p>");
    $("li").width("50%");

    $("li#one").width(125);
    $("li#two").width("75%");

    // const listWidth=$("#page").width();
    // $("ul").append("<p>Width : "+listWidth+"px</p>");
});