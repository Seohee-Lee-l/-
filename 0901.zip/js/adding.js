$(function() {
    $("ul").before("<p class='notice'> Just updated</p>");
    $("li.hot").prepend("+");

    const newList=$("<li><em>gluten-free </em>soy sauce</li>");
    $("li:last").after(newList);
});