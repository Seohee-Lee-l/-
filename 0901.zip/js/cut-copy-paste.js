$(function() {
    const p=$("p");
    const clonedQuote=p.clone();
    // clone() : 복사

    p.remove();
    clonedQuote.insertAfter("h2");
    // h2 뒤에 clonedQuote를 추가

    // p.after(h1): p 뒤에 h1을 추가
    // p.insertAfter(h1): h1 뒤에 p를 추가

    const moveItem=$("#one").detach();
    // detach() : 잘라내기
    moveItem.appendTo("ul");
    // ul 뒤에 (마지막에) moveItem(=#one) 추가
});