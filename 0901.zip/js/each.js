$(function() {
    $("li").each(function() {
        ids=$(this).attr("id");
        // 반복문에서... 현재 선택 요소의 id를 가져와서 ids에 대입함
        $(this).append("<span class='order'> "+ids+"</span>");
    });
});