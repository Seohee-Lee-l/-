$(function() {
    $("li:contains('pine')").text("almonds");
    // 텍스트 변경
    $("li.hot").html(function() {
        return "<em>"+$(this).text()+"</em>";
    });
    $("li#one").remove();
});