$(function() {
    $(".hamburger").click(function() {
        $(".menu").animate({marginLeft:"200px"}, 300);
    });

    $(".cross").click(function() {
        $(".menu").animate({marginLeft:"0px"}, 300);
    });


    $(".menu > ul > li > a").click(function() {
        if ($(this).next().is(":visible"))
        {
            $(this).next().stop().slideUp(500);
            $(this).children("img").attr("src", "img/arrow-down.png");
        } else {
            $(".sub").stop().slideUp(500);
            $(".menu > ul > li > a").children("img").attr("src", "img/arrow-down.png");
            // 서브 메뉴 초기화 (일단 다 접어 두고 선택된 메뉴만 나오도록)

            $(this).next().stop().slideDown(500);
            $(this).children("img").attr("src", "img/arrow-up.png");
        };
    });


    $("#bot > p").click(function() {
        if ($(this).next().is(":visible"))
        {
            $(this).next().stop().slideUp(500);
            $(this).children("img").attr("src", "img/arrow-down.png");
        } else {
            $("#bot .list").stop().slideUp(500);
            $("#bot > p > img").attr("src", "img/arrow-down.png");

            $(this).next().stop().slideDown(500);
            $(this).children("img").attr("src", "img/arrow-up.png");
        };
    });




    // 슬라이드
    let bnnNum=0;
    // 초기값 0



    // prev 버튼
    $(".prev").click(function() {
        if (bnnNum<=0) return false;
        bnnNum--;

        book_w=$("#main_image").width();
        $("#main_image ul").animate({left:-book_w*bnnNum}, 500, function() {
            $("#book_roll img").attr("src", "image/state_out.png");
            $("#book_roll img").eq(bnnNum).attr("src", "image/state_over.png");
        });
    });



    // next 버튼
    $(".next").click(function() {
        if (bnnNum>=3) return false;
        bnnNum++;

        book_w=$("#main_image").width();
        $("#main_image ul").animate({left:-book_w*bnnNum}, 500, function() {
            $("#book_roll img").attr("src", "image/state_out.png");
            // 일단 인디케이터 전부 회색(비활성화) 처리

            $("#book_roll img").eq(bnnNum).attr("src", "image/state_over.png");
        });
    });


    // 인디케이터
    $("#book_roll li a").click(function() {
        const strName=($(this).parent().attr("id"));
        slideTarget(strName.substr(3,1));
        return false;
    });

    function  slideTarget(n){
    const pos = Number( n ) * - 100+'%';
    $("#main_image ul").animate({left:pos},500,
    function(){
        $("#book_roll img").attr("src","image/state_out.png");
            $("#book_roll img").eq(n).attr("src","image/state_over.png");	
    });
};
});