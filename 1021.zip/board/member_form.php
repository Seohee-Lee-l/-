<? 
	session_start(); 
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="css/base.css">
        <link rel="stylesheet" href="css/join.css">     
		
		<script>



   function check_id()
   {
     window.open("check_id.php?id=" + document.member_form.id.value,
         "IDcheck",
          "left=200,top=200,width=200,height=60,scrollbars=no,resizable=yes");
   }


function check_input()
   {
   // const re1 = /^[a-zA-Z0-9]{4,12}$/ ;  //가능하다
   const re1 =/^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{6,10}$/;
    const id=document.member_form.id.value;
      if (!document.member_form.id.value)
      {
          alert("아이디를 입력하세요");    
          document.member_form.id.focus();
          return false;
      }else if(!re1.test(id)){
        alert("6~10자의 영문자,숫자,특수기호 혼합해서 사용할 수 있습니다");
    return false;
      }

      if (!document.member_form.name.value)
      {
          alert("이름을 입력하세요");    
          document.member_form.name.focus();
          return false;
      }



      if (!document.member_form.pass.value)
      {
          alert("비밀번호를 입력하세요");    
          document.member_form.pass.focus();
          return false;
      }

      if (!document.member_form.pass_confirm.value)
      {
          alert("비밀번호확인을 입력하세요");    
          document.member_form.pass_confirm.focus();
          return false;
      }


      if (document.member_form.pass.value != 
            document.member_form.pass_confirm.value)
      {
          alert("비밀번호가 일치하지 않습니다.\n다시 입력해주세요.");    
          document.member_form.pass.focus();
          document.member_form.pass.select();
          return false;
      }


      if (!document.member_form.tel.value)
      {
          alert("휴대폰 번호를 입력하세요");    
          document.member_form.tel.focus();
          return false;
      }


      if (!document.member_form.tel.value)
      {
          alert("전화번호를 입력하세요");    
          document.member_form.tel.focus();
          return false;
      }


      if (!document.member_form.email.value)
      {
          alert("Email을 입력하세요");    
          document.member_form.email.focus();
          return false;
      }



          
      document.member_form.submit();
   }

   function reset_form()
   {
      document.member_form.id.value = "";
      document.member_form.pass.value = "";
      document.member_form.pass_confirm.value = "";
      document.member_form.name.value = "";
      document.member_form.tel.value = "";
         document.member_form.email.value = "";
	  
      document.member_form.id.focus();

      return;
   }
</script>
		
		</head>
		
		
		<body>
        <div id="join_mem">
    <button class="close2" onclick="return false">&#735;</button>    
    <h2>회원가입</h2>
    <form class="cf" name="member_form" method="post" action="insert.php"  onsubmit="return check_input();">
     <div id="form_join">
        <label for="id">id</label>
        <div id="id1"><input type="text" name="id" id="id"></div>
        <div id="id2">
            <a href="#"><img src="formimg/checkn.png" onclick="check_id()" alt="check"></a>
        </div>
        <div id="id3">*4~12자의 영문 소문자, 숫자와 특수기호(_)만 
            사용할 수 있습니다.</div> 

    <label for="name">Name</label>
    <input type="text" maxlength="12" name="name" id="name"><br>      
    <label for="pwd">Password</label>
    <input type="password"  maxlength="10" name="pass" id="pwd"><br>   
    <label for="pwd1">Confirm Password</label>
    <input type="password"  maxlength="10" name="pass_confirm" id="pwd1"><br>
    <label for="ph">Phone number</label>
    <input type="tel"  maxlength="11" name="tel" id="ph">
    <label for="email">Email</label>
    <input type="email" id="email" name="email" >
    <div id="button">
        <input type="submit" value="submit" class="btn">
        <input type="reset" value="reset" onclick="reset_form()"> 
    </div>	 
   </div><!-- form_join 종료-->

</form>    
</div><!-- #join_mem 종료-->
	       
		
		</body>
		</html>

    