        <div class="inner">
        <h1><a href="sb.html"><img src="image/logo.png" alt="logo"></a></h1>
        <ul class="nav1 cf">
            <li>    <? include "top_login1.php"; ?></li>
            <li><a href="#">My Starbucks</a></li>
            <li><a href="#">Customer Service &amp; Ideas</a></li>
            <li><a href="#">Find a Store</a></li>
        </ul>
        <p class="search"><a href="#"><img src="image/s2.png" alt="search"
            width="20" height="20"></a></p>
        
        
    </div>
    <div class="menu">
     <div class="menubox cf">
    <ul class="nav2">
        <li class="a1"><a href="#">COFFEE</a>
        <div class="sub">
         <div class="sub1 cf"> 
             <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			   <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
	</div>
		</div>
        </li>
        <li class="a2"><a href="#">MENU</a>
            <div class="sub">
                 <div class="sub1">
             <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
			   <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
	</div>
            </div>
        </li>
        <li class="a3"><a href="#">STORE</a>
            <div class="sub">
            <div class="sub1">
             <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			   <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
	</div>
            </div>
        </li>
        <li class="a4"><a href="#">RESPONSIBILITY</a>
            <div class="sub">
                  <div class="sub1">
             <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
			   <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
	</div>
            </div>
        </li>
        <li class="a5"><a href="#">STARBUCKS REWARDS</a>
            <div class="sub">
			<div class="sub1">
               <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			   <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">목록1</a></li>
             	<li><a href="#">목록2</a></li>
             	<li><a href="#">목록3</a></li>
             	<li><a href="#">목록4</a></li>
             </ul>
			  </div>
            </div>
        </li>
        <li class="a6"><a href="board.html">BOARD</a>
            <!-- <div class="sub">
			<div class="sub1">
           <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
			   <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
			  <ul class="list1">
             	<li><a href="#">list1</a></li>
             	<li><a href="#">list2</a></li>
             	<li><a href="#">list3</a></li>
             	<li><a href="#">list4</a></li>
             </ul>
            </div>
			</div> -->
        </li>
    </ul>

</div>
</div>

</body>
</html>