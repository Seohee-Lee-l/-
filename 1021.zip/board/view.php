<? 
	session_start(); 

	include "dbconn.php";

	$num=$_GET['num'];
	$page=$_GET['page'];

	$sql = "select * from boardlist where num=$num";
	$result = mysqli_query( $connect,$sql);

    $row = mysqli_fetch_array($result);       
    // 하나의 레코드 가져오기
	
	$item_num     = $row['num'];
	$item_id      = $row['id'];
	$item_name    = $row['name'];
	$item_hit     = $row['hit'];

    $item_date    = $row['regist_day'];

	$item_subject = str_replace(" ", "&nbsp;", $row['subject']);

	$item_content = $row['content'];
	$is_html      = $row['is_html'];

	if ($is_html!="y")
	{
		$item_content = str_replace(" ", "&nbsp;", $item_content);
		$item_content = str_replace("\n", "<br>", $item_content);
	}	

	$new_hit = $item_hit + 1;

	$sql = "update boardlist set hit=$new_hit where num=$num";   // 글 조회수 증가시킴
	mysqli_query( $connect,$sql);
?>

<html>
<head> 
<meta charset="utf-8">
<link href="css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="css/greet.css" rel="stylesheet" type="text/css" media="all">

<link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/exam.css">

	<script src="js/jquery-1.11.2.min.js"></script>
<script>
$(function(){
 $(".nav2> li >a").on("mouseenter",function(){
   $(".nav2 li a").css("background","none");
   $(".sub").stop().slideUp(500);
   $(".nav2 li a").css("text-decoration","none");
   $(".nav2 li a").css("color","gray");
	$(this).css("background","#2c2a29");
	$(this).css("text-decoration","underline").css("color","#64a70b");	
	$(this).next().stop().slideDown(500);
 });
 
     $(".menu").on("mouseleave",function(){
     $(".nav2 li a").css("background","none");
	 $(".sub").stop().slideUp(500);
	 $(".nav2 li a").css("color","gray");
	 $(".nav2 li a").css("text-decoration","none");
	});

});
</script>
<script>
    function del(href) 
    {
        if(confirm("한번 삭제한 자료는 복구할 방법이 없습니다.\n\n정말 삭제하시겠습니까?")) {
                document.location.href = href;
        }
    }
</script>
</head>

<body>
	<div id="header">
		<? include "header.php"; ?>
    </div>

	<div id="wrap">

		<div id="content">
	

		<div id="col2">
        
			<div id="title">
				<img src="img/title_greet.gif">
			</div>

			<div id="view_comment"> &nbsp;</div>

			<div id="view_title">
				<div id="view_title1"><?= $item_subject ?></div>
				<div id="view_title2">
					<?= $item_id ?> | 조회 : <?= $item_hit ?> | <?= $item_date ?> 
				</div>	
			</div>

			<div id="view_content">
				<?= $item_content ?>
			</div>

			<div id="view_button">
			<a href="list.php?page=<?=$page?>"><img src="img/list.png"></a>&nbsp;
		<?

			$userid=$_SESSION['userid'];
			$item_id=$_SESSION['userid'];
			//if($userid==$item_id || $userlevel==1 || $userid=="admin")
			if($userid==$item_id)

			{
		?>
			<a href="modify_form.php?num=<?=$num?>&page=<?=$page?>"><img src="img/modify.png"></a>&nbsp;
			<a href="delete.php?num=<?=$num?>&page=<?=$page?>"><img src="img/delete.png"></a>&nbsp;				
		<?
			}
		?>

		<? 
		//	if($_SESSION['userid'])
			if($userid)
			{
		?>
			<a href="write_form.php"><img src="img/write.png"></a>
		<?
			}
		?>
		
		</div>

		<div class="clear"></div>

		</div> <!-- end of col2 -->
	</div> <!-- end of content -->
</div> <!-- end of wrap -->

</body>
</html>

