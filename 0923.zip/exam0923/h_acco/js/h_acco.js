$(function() {
	$("dd:not(:first)").css("width", "0px");
    $("dt:first span").addClass("selected");
    
    $("dl dt").click(function() {
        if ($("+dd", this).css("width")==='0px') {
            $("dt:has(span.selected) + dd").animate({"width": "0px"});

            $("+dd", this).animate({"width": "88%"});
            $("dt span").removeClass("selected");
            $("span", this).addClass("selected");
        }
    }).mouseover(function() {
        $("span", this).addClass("over");
    }).mouseout(function() {
        $("span", this).removeClass("over");
    });
});