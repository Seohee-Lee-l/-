$(function() {
    fullset();
    quickClick();

    function fullset() {
        let pageindex=$("#fullpage > .fullsection").size();

        for (let i=1; i<=pageindex; i++) {
            $("#fullpage > .quick > ul").append("<li></li>");
        }
        $("#fullpage .quick ul li:first-child").addClass("on");


        // 마우스 휠 이벤트
        $(window).bind("mousewheel", function(event) {
            let page=$(".quick ul li.on");

            if ($("body").find("#fullpage:animated").length>=1) return false;
            // 애니메이션이 진행중이면 return false

            if (event.originalEvent.wheelDelta>=0) {
                let before=page.index();

                if (page.index()>=0) page.prev().addClass("on").siblings().removeClass("on");

                let pagelength=0;

                for (let i=1; i<(before); i++) {
                    pagelength+=$(".full"+i).height();
                }

                if (page.index()>0) {
                    page=page.index()-1;
                    $("#fullpage").animate({"top": -pagelength+'px'}, 1000, 'swing');
                } else {
                    alert("첫번째 페이지입니다.");
                }
            }
        });
    }
});