$(function() {
    $("#fullpage").fullpage({
        anchors: ['asection0', 'asection1', 'asection2', 'asection3', 'asection4', 'asection5', 'asection6'],

        // 섹션에 도착하면
        afterLoad: function(anchorLink, index) {
            if (index%2==0) {
                $("h2").addClass("down");
            } else {
                $("h2").removeClass("down");
            }
        },

        css3: false,
    });
});


/*
anchors: 각 슬라이드(섹션)에 대한 앵커를 지정. 이 값들은 URL 해시로 사용될 수 있음
afterLoad: 각 섹션이 로드될 때마다 실행되는 함수
fullPage.js가 CSS3 트랜지션을 사용하지 않도록 설정. 특정 브라우저에서의 호환성 문제를 방지
*/