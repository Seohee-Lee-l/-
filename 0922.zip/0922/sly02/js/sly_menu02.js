﻿$(function(){
	const $frame = $('#basic');
    const $wrap = $frame.parent();
    $frame.sly({
        horizontal: 1,        // 가로 방향 스크롤 활성화
        itemNav: 'basic',   
        smart: 1,            //활성화된 아이템이 중앙 근처에 오도록 자동 조절
        activateOn: 'click',  // 아이템을 클릭했을 때 활성화
        mouseDragging: 1,     // 마우스 드래그로 스크롤 가능
        touchDragging: 1,     // 터치 드래그로 스크롤 가능
        releaseSwing: 1,      // 드래그 후 스윙 효과 활성화
        startAt: 0,           // 첫 번째 아이템부터 시작
        scrollBy: 1,          // 한 번에 한 아이템씩 스크롤
        pagesBar: $wrap.find('.pages'), // 페이지 바 요소를 지정 (부모 요소 내 '.pages' 클래스 요소)
        activatePageOn: 'click',        // 페이지 바 클릭 시 해당 페이지로 이동
        speed: 300,
        elasticBounds: 1,    // 탄성 경계 활성화 (스크롤 끝에서 살짝 튕김 효과)
        dragHandle: 1,       // 드래그 핸들 사용
        dynamicHandle: 1,    // 핸들 크기가 내용에 따라 동적으로 변함 
        clickBar: 1         // 클릭 바 활성화 (바 클릭 시 스크롤 이동)
    });
});

