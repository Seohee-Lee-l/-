﻿$(function(){
    const menu_start='0';
    $("#mobile_nav").sly({
        horizontal: 1,
        itemNav: "centered",
        smart: 1,
        mouseDragging: 1,
        touchDragging: 1,
        releaseSwing: 1,
        startAt: menu_start,
        speed: 300,
        elasticBounds: 1,
        dragHandle: 1,
        dynamicHandle: 1,
    });

    $(window).resize(function(e) {
        $("#mobile_nav").sly("reload");
    });


	const menu_start02='0';
    const $wrap=$("#mobile_nav02").parent();
    $("#mobile_nav02").sly({
        horizontal: 1,        // 가로 방향 스크롤 활성화
        itemNav: 'centered',   
        smart: 1,            //활성화된 아이템이 중앙 근처에 오도록 자동 조절
        mouseDragging: 1,     // 마우스 드래그로 스크롤 가능
        touchDragging: 1,     // 터치 드래그로 스크롤 가능
        releaseSwing: 1,      // 드래그 후 스윙 효과 활성화
        startAt: menu_start02,           // 첫 번째 아이템부터 시작
        scrollBar: $wrap.find('.scrollbar'),
        scrollBy: 1,          // 한 번에 한 아이템씩 스크롤
        speed: 300,
        elasticBounds: 1,    // 탄성 경계 활성화 (스크롤 끝에서 살짝 튕김 효과)
        dragHandle: 1,       // 드래그 핸들 사용
        dynamicHandle: 1,    // 핸들 크기가 내용에 따라 동적으로 변함 
    });

    $(window).resize(function(e) {
        $("#mobile_nav02").sly("reload");
    });
});