$(function() {
    const $frame=$("#basic");
    const $wrap=$frame.parent();

    $frame.sly ({
        horizontal: 1,
        // 가로 방향 스크롤 활성화

        itemNav: 'centered',
        

        smart: 1,
        // 활성화된 아이템이 중앙 근처에 오도록 자동 조절
        
        activateOn: "click",
        // 아이템을 클릭했을 때 활성화

        mouseDragging: 1,
        // 마우스 드래그로 스크롤

        touchDragging: 1,
        // 터치 드래그로 스크롤

        releaseSwing: 1,
        // 드래그 후 스윙 효과 활성화

        startAt: 0,
        // 첫 번째 아이템부터 시작

        scrollBar: $wrap.find(".scrollbar"),

        scrollBy: 1,
        // 한 번에 한 아이템씩 스크롤

        pageBar: $wrap.find(".pages"),
        activatePageOn: "click",
        speed: 300,
        elasticBounds: 1,
        dragHandle: 1,
        dynamicHandle: 1,
        clickBar: 1
    });
});