create table sungj (
    id varchar(8),
    name varchar(12),
    kor int,
    eng int,
    mat int,
    primary key(id)
);