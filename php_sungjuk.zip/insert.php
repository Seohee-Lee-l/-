<meta charset="utf-8">

<!-- 
    sungj.php의 폼에서 받은 값을 여기에서 받음
    input의 name 속성값으로 받고 변수에 저장
-->

<?php
    $id=$_POST['id'];
    $name=$_POST['name'];
    $kor=$_POST['kor'];
    $eng=$_POST['eng'];
    $mat=$_POST['mat'];

    include "dbconn.php";
    // dbconn.php : DB 연결 설정 파일
    // dbconn.php 파일을 불러옴


    $sql="SELECT * FROM sungj";
    $result=mysqli_query($connect, $sql);
    // SQL 명령 실행

    $sql="INSERT INTO sungj(id, name, kor, eng, mat) values";
    // sungj 테이블에 레코드(데이터) 삽입
    $sql.="('$id', '$name', $kor, $eng, $mat)";
    // 입력한 값들을 변수에 저장하여 SQL 명령 완성

    $result=mysqli_query($connect, $sql);

    mysqli_close($connect);
    // DB 연결 닫기

    echo "
    <script>
        location.href='sungj.php';
    </script>
    ";
    // 입력 후 (인서트 후) 다시 sungj.php로 돌아감
?>