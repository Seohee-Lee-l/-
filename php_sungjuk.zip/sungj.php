<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        tr, td {
            text-align: center;
            border: none;
        }

        table {
            padding: 20px;
            box-sizing: border-box;
        }

        .tb {
            border: none;
        }
    </style>
</head>

<body>
    <h3>데이터 입력하기</h3>

    <form action="insert.php" method='post'>
        <table width='900' border='1'>
            <tr>
                <td>
                    ID : <input type='text' size='6' name='id'>&nbsp;
                    이름 : <input type='text' size='6' name='name'>&nbsp;
                    KOR : <input type='text' size='6' name='kor'>
                    ENG : <input type='text' size='6' name='eng'>
                    MAT : <input type='text' size='6' name='mat'>
                </td>

                <td>
                    <input type="submit" value='입력하기'>
                </td>
            </tr>
        </table>
    </form>

    <table width='900' border='1' class='tb'>
        <tr>
            <td>ID</td>
            <td>이름</td>
            <td>KOR</td>
            <td>ENG</td>
            <td>MAT</td>
        </tr>

        <?
            include "dbconn.php";
            // dbconn.php 데이터베이스 연결
            $sql="SELECT * FROM sungj";
            // sungj 테이블의 전체 레코드(데이터) 검색
            $result=mysqli_query($connect, $sql);
            // SQL 명령 실행

            while ($row=mysqli_fetch_array($result)) {
                echo "
                    <tr>
                        <td>$row[id]</td>
                        <td>$row[name]</td>
                        <td>$row[kor]</td>
                        <td>$row[eng]</td>
                        <td>$row[mat]</td>
                    </tr>
                ";
            }
            mysqli_close($connect);
        ?>
    </table>
</body>

</html>