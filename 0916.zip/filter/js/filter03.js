$(function() {
    const $imgs = $("#gallery img");
    const $search = $("#filter-search");
    const cache = [];

    $imgs.each(function() {
        cache.push({
            element: this,
            text: this.alt.trim().toLowerCase()
            // trim() : 앞뒤 공백 제거
            // toLowerCase() : 소문자로 변환
        });
    });

    function filter() {
        const query = this.value.trim().toLowerCase();
        cache.forEach(function(img) {
            let index = 0;

            if (query) {
                index = img.text.indexOf(query);
            }
            img.element.style.display = index === -1 ? "none" : "";
            // index가 -1이면 none, 아니면 ""(기본값)
            // -1이면 안 보이는 것
        });
    }

    $search.on("keyup", filter);
});