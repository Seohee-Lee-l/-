$(function() {
    const $imgs=$("#gallery img");
    const $buttons=$("#buttons");
    const tagged={};
    // 이미지들을 태그별로 분류하기 위한 빈 객체

    $imgs.each(function() {
        const img=this;
        // 현재 이미지 요소

        const tags=$(this).data("tags");

        if (tags) {
            tags.split(',').forEach(function(tagName) {
                if (tagged[tagName]==null) {
                    tagged[tagName]=[];
                }
                tagged[tagName].push(img);
            });
        }
        // 각 이미지 요소에 대해 data-tags 속성의 값을 가져와서
        // 쉼표(,)로 구분된 태그들을 배열로 만듦
        // 각 태그에 대해 tagged 객체에 해당 태그가 없으면 빈 배열을 생성하고
        // 해당 태그에 현재 이미지 요소를 추가
    });
    // .each() 종료


    $("<button>", {
        text: "ShowAll",
        // 버튼에 표시될 텍스트

        class: "active",
        // 버튼이 기본적으로 활성 상태임을 나타냄

        click: function() {
            $(this).addClass("active").siblings().removeClass("active");
            $imgs.show();
        }
    }).appendTo($buttons);
    // 만든 버튼을 실제 버튼 영역에 추가


    $.each(tagged, function(tagName) {
        $("<button>", {
            text: tagName+"("+tagged[tagName].length+")",
            click: function() {
                $(this).addClass("active").siblings().removeClass("active");
                $imgs.hide().filter(tagged[tagName]).show();
            }
        }).appendTo($buttons);
    });
});