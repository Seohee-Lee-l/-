﻿$(function(){
    // 현재 시간 출력
    const timer=setInterval(function(){
        const now=new Date();
        const hr=now.getHours();
        const min=now.getMinutes();
        const sec=now.getSeconds();

        let hNum, mNum, sNum;

        if (hr>=10) {
            hNum=hr;
        } else {
            hNum="0"+hr;
        };

        if (min>=10) {
            mNum=min;
        } else {
            mNum="0"+min;
        };

        if (sec>=10) {
            sNum=sec;
        } else {
            sNum="0"+sec;
        };


        $("p span").eq(0).text(hNum);
        $("p span").eq(1).text(mNum);
        $("p span").eq(2).text(sNum);
    }, 1000);



    // 시간대별 배경 및 메뉴 변경
    const now=new Date();
    const hr=now.getHours();

    // 5~10 아침, 11~15 낮, 16~19 저녁, 20~24 밤
    if (hr>=5 && hr<11) {
        $("#wrap").removeClass();
        $("#wrap").addClass("morning");
        $("nav li").removeClass();
        $("nav li").eq(0).addClass("on");
    } else if (hr>=11 && hr<16) {
        $("#wrap").removeClass();
        $("#wrap").addClass("afternoon");
        $("nav li").removeClass();
        $("nav li").eq(1).addClass("on");
    } else if (hr>=16 && hr<20) {
        $("#wrap").removeClass();
        $("#wrap").addClass("evening");
        $("nav li").removeClass();
        $("nav li").eq(2).addClass("on");
    } else if (hr>=20 && hr<25) {
        $("#wrap").removeClass();
        $("#wrap").addClass("night");
        $("nav li").removeClass();
        $("nav li").eq(3).addClass("on");
    }


    // 메뉴 클릭시 배경 및 메뉴 변경
    $("nav li").on("click", function() {
        const className=$(this).children("a").text();

        $("nav li").removeClass();
        $(this).addClass("on");

        $("#wrap").removeClass();
        $("#wrap").addClass(className);
    });
});












