$(function() {
    const $items=$("#bestseller_box li");
    const totalItems=$items.length;
    let visibleCount=0;

    function getShow() {
        const winWidth=$(window).width();

        if (winWidth <= 640) {
            return 2;
        } else if (winWidth <= 768) {
            return 3;
        } else {
            return 4;
        }
    }


    function update(countToShow) {
        // 모두 숨기고 필요한 만큼만 보여주기

        $items.hide();
        $items.slice(0, countToShow).show();


        // more 버튼 보이기/숨기기
        if (countToShow >= totalItems) {
            $(".more_btn").hide();
        } else {
            $(".more_btn").show();
        }
    }


    function initializeList() {
        const showCount=getShow();
        
        visibleCount=Math.max(visibleCount, showCount);
        // 기존 visibleCount와 비교해서 더 큰 수로 설정 (줄이지 않음)
        update(visibleCount);
    }

    initializeList();



    // more 버튼 클릭 시
    $(".more_btn").on("click", function() {
        const showCount=getShow();
        visibleCount+=showCount;

        if (visibleCount > totalItems) {
            visibleCount=totalItems;
        }
        update(visibleCount);
    });


    $(window).on("resize", function() {
        initializeList();
    });
});