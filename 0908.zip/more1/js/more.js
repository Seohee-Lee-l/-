$(function() {
    // listMore() 함수
    function listMore() {
        const $items=$("#bestseller_box li");
        const totalItems=$items.length;
        let showCount=0;

        // 현재 화면 너비 기준으로 한 번에 보여줄 개수 설정
        const winWidth=$(window).width();

        if (winWidth <=640) {
            showCount=2;
        } else if (winWidth<=768) {
            showCount=3;
        } else {
            showCount=4;
        }


        // 초기 상태 설정
        $items.hide();
        $items.slice(0, showCount).show();
        // slice(0, 3).show() >> 0~2번째 요소까지 선택해서 표시
        // slice(0, showCount).show() >> 0~showCount-1번째 요소까지 선택해서 표시


        /* 
            .off("click") : 기존에 등록되어 있던 클릭 이벤트 핸들러를 제거
            중복 등록을 방지하기 위해 이벤트를 먼저 제거하고 새로 등록
            여러 개의 이벤트 핸들러가 한꺼번에 실행되어 이미지가 한 번에 여러 개씩 나오는 문제 해결
        */
        // "More" 버튼 클릭 시 추가 항목 표시
        $(".more_btn").off("click").on("click", function() {
            let visibleCount=$("#bestseller_box li:visible").length;
            let nextCount=visibleCount+showCount;
            if (nextCount > totalItems) nextCount=totalItems;

            $items.slice(0, nextCount).show();

            // 더 이상 보여줄 항목이 없다면 버튼 숨기기
            if (nextCount===totalItems) {
                $(".more_btn").hide();
            }
        });


        // 버튼 초기화 상태 (처음에 전체 안 보여주면 보여줌)
        if (showCount<totalItems) {
            $(".more_btn").show();
        } else {
            $(".more_btn").hide();
        }
    }

    listMore();


    // 창 크기 변경 시 다시 적용
    $(window).on("resize", function() {
        listMore();
    });
});