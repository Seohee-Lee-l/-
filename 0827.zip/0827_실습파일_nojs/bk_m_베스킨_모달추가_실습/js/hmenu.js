document.addEventListener("DOMContentLoaded", function() {
      const menu=document.querySelector(".menu");
      const hamburger=document.querySelector(".hm img");
      const closeBtn=document.querySelector(".cross");
      const mainLinks=document.querySelectorAll(".mm > li > a");


      // 메뉴 열기
      hamburger.addEventListener("click", function() {
          menu.style.transition='margin-right 0.3s';
          menu.style.marginRight='75%';

          closeBtn.style.display='block';
          closeBtn.style.color='#fff';
      });



      // 메뉴 닫기
      closeBtn.addEventListener("click", function() {
        menu.style.marginRight='0';
        closeBtn.style.display='none';
      });


      // 서브 메뉴 열기 / 닫기
      mainLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
          e.preventDefault();

          const subMenu=this.nextElementSibling;
          const isVisible=subMenu.style.display==='block';


          // 모든 서브 메뉴 닫기
          document.querySelectorAll(".sub").forEach(function(x) {
            x.style.display='none';
          });


          // 모든 아이콘 초기화
          document.querySelectorAll(".mm > li > a > img").forEach(function(img) {
            img.setAttribute("src", "img/ico_nav.png");
          });

          if (!isVisible) {
            subMenu.style.display='block';
            const img=this.querySelector("img");
            if (img) img.setAttribute("src", "img/ico_nav_on.png");
          }
        });
      });



      // 모달 부분
      const modalBack=document.querySelector(".modal_back");
      const openBtn=document.querySelector(".hm img");
      const closeBtn1=document.querySelector(".cross");

      function modalOn() {
        modalBack.classList.add("back_on");
      };

      function modalOff() {
        modalBack.classList.remove("back_on");
      };

      openBtn.addEventListener("click", modalOn);
      closeBtn1.addEventListener("click", modalOff);
});