document.addEventListener("DOMContentLoaded", function() {
    const hamburger=document.querySelector(".hamburger");
    const cross=document.querySelector(".cross");
    const menu=document.querySelector(".menu");
    const body=document.body;


    // 메뉴 열기
    hamburger.addEventListener("click", function() {
        body.style.transition='margin-left 0.3s';
        menu.style.transition='margin-left 0.3s';

        body.style.marginLeft='200px';
        menu.style.marginLeft='200px';

        cross.style.display='block';
        hamburger.style.display='none';
    });


    // 메뉴 닫기
    cross.addEventListener("click", function() {
        body.style.marginLeft='0';
        menu.style.marginLeft='0';

        cross.style.display='none';
        hamburger.style.display='block';
    });


    // 서브 메뉴 토글
    const menuLinks=document.querySelectorAll(".menu > ul > li > a");
    
    menuLinks.forEach(function (link) {
        link.addEventListener("click", function (e) {
            e.preventDefault();

            const subMenu=link.nextElementSibling;

            if (subMenu&&subMenu.style.display==='block') {
                subMenu.style.display='none';

                const img=link.querySelector("img");

                if (img) img.src='img/arrow-down.png';
                return;
            }

            // 모든 서브 메뉴 닫기
            document.querySelectorAll(".sub").forEach(function(menu) {
                menu.style.display='none';
            });

            // 모든 화살표 이미지 초기화
            menuLinks.forEach(function(l) {
                const img=l.querySelector("img");
                if (img) img.src='img/arrow-down.png';
            });

            // 선택한 서브 메뉴 열기
            if (subMenu && subMenu.classList.contains("sub")) {
                subMenu.style.display='block';

                const img=link.querySelector("img");
                if (img) img.src="img/arrow-up.png";
            }
        });
    });
});