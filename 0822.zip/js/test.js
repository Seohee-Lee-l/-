function validateForm() {
    const f=document.member;
    const reg_exp=new RegExp("^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{6,10}$");
    const match=reg_exp.exec(f.id.value);
    // exec 메서드가 일치하는 부분을 찾지 못하면 null 반환
    if (match==null) {
        alert(`6~10자의 영문자, 숫자, 특수기호 혼합해서 사용할 수 있습니다`);
        return false;
    };

    const x1=document.forms['member']['name'].value;
    if (x1=='') {
        alert(`이름을 입력하세요.`);
        return false;
    };

    const reg_exp1=new RegExp("^(?=.*[a-zA-Z])(?=.*[0-9]).{4,8}$");
    const match1=reg_exp1.exec(f.pass.value);
    if (match1==null) {
        alert(`숫자와 영문자 조합으로 4~8자리를 사용해야 합니다`);
        return false;
    };

    const x3=document.forms['member']['pass'].value;
    const x4=document.forms['member']['pass_confirm'].value;
    if (x3!=x4) {
        alert(`비밀번호가 일치하지 않습니다.`);
        return false;
    };

    const x5=document.forms['member']['tel'].value;
    if (x5=='') {
        alert(`전화번호를 입력하세요`);
        return false;
    };

    const x6=document.forms['member']['email'].value;
    if (x6=='') {
        alert(`Email을 입력하세요`);
        return false;
    };

    const sns=0;
    const form=document.member;
    for (let i=0; i<form.a1.length; i++) {
        if (form.a1[i].checked==1) {
            sns='1';
        }
    }
    if (sns=='0') {
        alert(`회원님의 성별을 선택해주시기 바랍니다`);
        return false;
    };
}