<?
    session_start();
?>

<div id='top_login'>
    <?
        if(!$_SESSION['userid']) {
    ?>

    <a href="login_firm.php">LOGIN</a>
    <a href="member_conditions.html">JOIN</a>

    <?
        } else {
    ?>

    <?=$_SESSION['usderid']?>
    <a href="logout.php">LOGOUT</a>
    <a href="member_form.php">정보수정</a>
    <a href="member_delete.php">회원탈퇴</a>

    <?
        }
    ?>
</div>