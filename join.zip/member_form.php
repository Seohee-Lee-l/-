<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/member.css">
    <link rel="stylesheet" href="css/common.css">

    <script>
        // 아이디 중복 검사
        function check_id() {
            window.open("check_id.php?id="+document.member_form.id.value, "IDcheck", "left=200, top=200, width=200, height=60, scrollbars=no, resizable=yes");
        }

        // 닉네임 중복 검사
        function check_nick() {
            window.open("check_nick.php?nick="+document.member_form.nick.value, "NICKcheck", "left=200, top=200, width=200, height=60, scrollbars=no, resizable=yes");
        }

        // 저장하기 버튼
        function check_input() {
            const rel =/^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{6,10}$/;
            const id=document.member_form.id.value;
            
            if (!document.member_form.id.value) {
                alert("아이디를 입력하세요");
                document.member_form.id.focus();
                return;
            } else if (!rel.test(id)) {
                alert("6~10자의 영문자, 숫자, 특수기호를 혼합해서 사용할 수 있습니다");
                return false;
            }

            if (!document.member_form.pass.value) {
                alert("비밀번호를 입력하세요");

                document.member_form.pass.focus();
                return;
            }

            if (!document.member_form.pass_confirm.value) {
                alert("비밀번호 확인을 입력하세요");

                document.member_form.pass_confirm.focus();
                return;
            }

            if (!document.member_form.name.value) {
                alert("이름을 입력하세요");

                document.member_form.name.focus();
                return;
            }

            if (!document.member_form.nick.value) {
                alert("닉네임을 입력하세요");

                document.member_form.nick.focus();
                return;
            }

            if (!document.member_form.hp.value) {
                alert("휴대폰 번호를 입력하세요");

                document.member_form.hp.focus();
                return;
            }

            if (!document.member_form.email.value) {
                alert("이메일을 입력하세요");

                document.member_form.email.focus();
                return;
            }

            if (document.member_form.pass.value != document.member_form.pass_confirm.value) {
                alert("비밀번호가 일치하지 않습니다 \n 다시 입력해주세요.");

                document.member_form.pass.focus();
                document.member_form.pass.select();
                return;
            }

            document.member_form.submit();
            // insert.php 로 전송
        }

        // id는 name 값

        function reset_form() {
            document.member_form.id.value="";
            document.member_form.pass.value="";
            document.member_form.pass_confirm.value="";
            document.member_form.name.value="";
            document.member_form.nick.value="";
            document.member_form.hp.value="";
            document.member_form.email.value="";

            document.member_form.id.focus();
            return;
        }
    </script>
</head>

<body>
    <h2>회원가입</h2>

    <div id='join_mem'>
        <form name="member_form" method='post' action='insert.php'>
            <div id='form_join'>
                <div id='join1'>
                    <ul>
                        <li>* 아이디</li>
                        <li>* 비밀번호</li>
                        <li>* 비밀번호 확인</li>
                        <li>* 이름</li>
                        <li>* 닉네임</li>
                        <li>* 휴대폰</li>
                        <li>* 이메일</li>
                    </ul>
                </div>

                <div id='join2'>
                    <ul>
                        <li>
                            <div id='id1'>
                                <input type="text" name='id'>
                            </div>

                            <div id='id2'>
                                <a href="#">
                                    <img src="image/check_id.gif" onclick="check_id()">
                                </a>
                            </div>
                        </li>

                        <li>
                            <input type="password" name='pass'>
                        </li>

                        <li>
                            <input type="password" name='pass_confirm'>
                        </li>

                        <li>
                            <input type="text" name='name'>
                        </li>

                        <li>
                            <div id='nick1'>
                                <input type="text" name='nick'>
                            </div>

                            <div id='nick2'>
                                <a href="#">
                                    <img src="image/check_id.gif" onclick="check_nick()">
                                </a>
                            </div>
                        </li>

                        <li>
                            <input type="tel" class='hp' name='hp'>
                        </li>

                        <li>
                            <input type="email" id='email1' name='email'>
                        </li>
                    </ul>
                </div>

                <div class='clear'></div>

                <div id='must'>
                    *는 필수 입력 항목입니다.^^
                </div>
            </div>

            <div id='button'>
                <a href="#"><img src="image/button_save.gif" onclick="check_input()"></a>&nbsp;&nbsp;
                <a href="#"><img src="image/button_reset.gif" onclick='reset_form()'></a>
            </div>
        </form>
    </div>
</body>

</html>