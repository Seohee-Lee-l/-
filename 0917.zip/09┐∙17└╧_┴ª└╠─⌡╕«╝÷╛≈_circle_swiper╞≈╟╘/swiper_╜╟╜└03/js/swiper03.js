$(function(){
    const  swiper=new Swiper('.menu>.swiper-container', { 
        slidesPerView: 5,
        loop: true,
        spaceBetween: 0,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        paginationClickable: true,
        autoplay: 2000, 
        autoplayDisableOnInteraction: false,
        breakpoints: {  
            1049: {//까지
                slidesPerView: 4,
                spaceBetween: 0,
                loop: true,
                autoplay: 2000,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
                },
             900: { //까지
                    slidesPerView: 3,
                    spaceBetween: 0,
                    loop: true,
                    autoplay: 2000,
                    nextButton: '.swiper-button-next',
                    prevButton: '.swiper-button-prev',
                },
            640: {//까지
                    slidesPerView: 2,
                    spaceBetween: 0,
                    loop: true,
                    autoplay: 2000,
                    nextButton: '.swiper-button-next',
                    prevButton: '.swiper-button-prev',
                },
                420: { //까지  
                    slidesPerView: 1,       
                    spaceBetween: 0,     
                    loop: true,
                    autoplay: 2000,
                    nextButton: '.swiper-button-next',
                    prevButton: '.swiper-button-prev',
                 } 
            }
      });	 
});