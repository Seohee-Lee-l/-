// $(function(){
//     const perNum = 80; //원형 그래프가 80%까지 찬다는 의미
//     $('.wp2').waypoint(function(){
//         $('.wp2').addClass('animated fadeIn');
//         // .wp2에 애니메이션 클래스 추가 (fadeIn)

//         // .second.circle에 원형 프로그레스바 플러그인 적용
//         $('.second.circle').circleProgress({
//           value: perNum/100,
//           // perNum=80 >> 80/100=0.8

//           startAngle:300,
//           // 시작 각도 300도

//           size:300,
//           // 원형 그래프 크기 (300px)

//           fill:{
//               color:["tomato"]
//             },
//           // 채워지는 색상

//           animation:{
//             duration:1500,
//             // 애니메이션 시간 (1.5초)

//             easing:"swing" 
//             //swing : 시작 / 끝에서는 느리게 움직이지만 중간에서는 빨라짐
//           },

//           //  lineCap : "rect",
//           lineCap : "round",
//           // 끝부분 둥글게
//           reverse:true              
//           // 반시계 방향으로 진행
          

//         // 애니메이션 진행 중 퍼센트 숫자 업데이트
//         // circle-animation-progress : 플러그인 제공 이벤트
//         }).on('circle-animation-progress', function(event, progress) {
//   $(this).find('strong').html(Math.round(perNum * progress) + '<i>%</i>');
//             });
//         }, {
//             offset:'75%' 
//         });
// });




$(function() {
    const perNum = 80;

    $(".wp2").waypoint(function() {
        $('.wp2').addClass("animated fadeIn");

        $(".second.circle").circleProgress({
            value: perNum / 100,
            startAngle: 300,
            size: 300,
            fill: {
                color: ['tomato']
            },
            animation: {
                duration: 1500,
                easing: 'swing'
            },
            lineCap: 'round',
            reverse: true
        }).on("circle-animation-progress", function(event, progress) {
            $(this).find("strong").html(Math.round(perNum * progress) + '<i>%</i>');
        });
    }, { offset: '75%' });
});