$(function() {
    const swiper = new Swiper('.swiper-container', {
        slidesPerView: 5,
        spaceBetween: 5,
        loop: false,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        autoplay: 2000,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        
        breakpoints: {
            1759: {
                slidesPerView: 4,
                spaceBetween: 10,
                loop: true,
                autoplay: 2000,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
            },
            1336: {
                slidesPerView: 3,
                spaceBetween: 10,
                loop: true,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
            },
            1055: {
                slidesPerView: 3,
                spaceBetween: 10,
                loop: true,
                autoplay: 2000,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
            },
            911: {
                slidesPerView: 3,
                spaceBetween: 10,
            },
            800: {
                slidesPerView: 3,
                spaceBetween: 10,
                loop: true,
                autoplay: 2000,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
            },
            736: {
                slidesPerView: 2,
                spaceBetween: 10,
                loop: true,
                autoplay: 2000,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
            },
            480: {
                slidesPerView: 1,
                spaceBetween: 10,
                loop: true,
                autoplay: 2000,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
            },
        }
    });
});