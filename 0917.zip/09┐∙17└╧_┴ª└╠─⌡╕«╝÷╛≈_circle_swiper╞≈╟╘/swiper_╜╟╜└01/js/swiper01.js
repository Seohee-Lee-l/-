$(function(){
    const swiper = new Swiper('.swiper-container', {
        pagination: '.swiper-pagination',
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        paginationClickable: true,
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: 2500,
        autoplayDisableOnInteraction: false
    });	
});

/*
autoplayDisableOnInteraction: false
    사용자가 슬라이더를 조작해도 자동 재생(autoplay)이 계속됨.
    true (기본값)
*/