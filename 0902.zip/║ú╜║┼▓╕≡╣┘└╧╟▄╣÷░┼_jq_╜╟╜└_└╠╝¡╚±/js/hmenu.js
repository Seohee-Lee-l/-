$(function() {
    $(".hm").click(function() {
        $(".menu").animate({right:"0"}, 500);
        $(".cross").css("display", "block").css("color", "#fff");
    });

    $(".cross").click(function() {
        $(".menu").animate({right: "-75%"}, 500);
        $(".cross").css("display", "none");
    });



    $(".mm > li > a").click(function() {
        if ($(this).next().is(":visible")) {
            $(this).next().stop().slideUp(300);
            $(this).children("img").attr("src", "img/ico_nav.png");
        } else {
            $(".sub").stop().slideUp(300);
            $(".mm > li > a").children("img").attr("src", "img/ico_nav.png");

            $(this).next().stop().slideDown(300);
            $(this).children("img").attr("src", "img/ico_nav_on.png");
        }
    });
});