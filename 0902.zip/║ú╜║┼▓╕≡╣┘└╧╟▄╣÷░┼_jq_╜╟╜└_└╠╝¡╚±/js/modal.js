$(function() {
    function modalOn() {
        $(".modal_back").addClass("back_on");
        $("body").addClass("body_lock");
        // 모달 뒤 화면 스크롤 잠금
    };

    function modalOff() {
        $(".modal_back").removeClass("back_on");
        $("body").removeClass("body_lock");
    };

    $(".hm").click(function() {
        modalOn();
    });
    $(".cross").click(function() {
        modalOff();
    });
});