$(function() {
    const visual=$("#brandVisual > ul > li");
    const button=$("#buttonList > li");
    let current=0;
    let setIntervalId;

    button.on({click:function() 
        {
            const tg=$(this);
            const i=tg.index();
            button.removeClass('on');
            tg.addClass("on");

            move(i);
        }
    });

    // 작업 1
    $("#wrap").on({
        mouseover:function(){
            clearInterval(setIntervalId);
            // 마우스 올리면 자동 슬라이드 정지
        },
        mouseout:function(){
            timer();
        }
    });


    // 작업 2
    timer();

    function timer() {
        setIntervalId=setInterval(function() {
            let n=current+1;
            if (n==visual.size()) {
                n=0;
            }

            button.eq(n).trigger('click');
        }, 3000);
    };



    // move()
    function move(i) {
        if (current==i) return;
    /* 현재 활성화된 버튼을 다시 누르면 오류 현상 나타날 수 있기 때문에 활성화와 다시 클릭한 인덱스와 같으면 활성화 처리 수행 중지 */

    const currentEl=visual.eq(current);
    // 기존 활성화 인덱스로 활성화되어 있는 이미지를 선택하여 할당

    const nextEl=visual.eq(i);
    // 활성화 시킬 이미지

    currentEl.css({left:0}).stop().animate({left:"-100%"});
    // 이미 활성화된 이미지(중앙)에서 좌측으로 이동 (-100%)

    nextEl.css({left:"100%"}).stop().animate({left:0});
    // 중앙에 활성화 시킬 이미지 우측(100%)에서 중앙(0)으로 이동

    current=i;
    }
    // move 함수 종료
});