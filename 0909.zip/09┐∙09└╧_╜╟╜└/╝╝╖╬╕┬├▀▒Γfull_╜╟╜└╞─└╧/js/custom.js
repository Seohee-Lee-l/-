﻿$(function() {
    // 페이지 로딩 시 맨위로 이동
    $("body, html").stop().animate({"scrollTop": 0}, 1500, "swing");

    // 브라우저의 높이 값을 section의 높이값으로 지정
    function setSectionHeight() {
        const ht=$(window).height();
        $("section").height(ht);
    };

    setSectionHeight();


    // 브라우저 리사이즈 시 높이 다시 설정
    $(window).on("resize", setSectionHeight);


    // 메뉴 클릭 시 해당 section으로 이동
    $("#menu li").on("click", function() {
        const ht=$(window).height();
        const i=$(this).index();
        const nowTop=i*ht;

        $("html, body").stop().animate({"scrollTop": nowTop}, 1400);
    });



    // 스크롤 시 메뉴 표시 변경
    $(window).on("scroll", function() {
        const ht=$(window).height();
        const scroll=$(window).scrollTop();
        // 현재 스크롤된 위치(위에서부터 얼마나 내렸는지)를 구함


        // section이 4개 있음 (i<4) / 각 section의 구간을 반복
        for (let i=0; i<4; i++) {
            if (scroll>=ht*i && scroll<ht*(i+1)) {
            // 만약 스크롤 위치가 i번째 section의 범위에 들어오면 
                $("#menu li").removeClass();
                $("#menu li").eq(i).addClass("on");
                // 현재 구간에 해당하는 메뉴 li에만 on 클래스 추가
            }
        }
    });


    // mousewheel 이벤트

    // delta > 0 : 마우스 휠을 올렸을 때
    // delta < 0 : 마우스 휠을 내렸을 때
    $("section").on("mousewheel", function(event, delta) {
            if (delta>0) {
            const prev=$(this).prev().offset().top;
            $("html, body").stop().animate({"scrollTop": prev}, 1400, "easeOutBounce")
        } else if (delta<0) {
            const next=$(this).next().offset().top;
            $("html, body").stop().animate({"scrollTop": next}, 1400)
        }
    });
});