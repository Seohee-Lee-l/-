﻿$(function() {
    let imgs='';
    
    for (let i=0; i<10; i++) {
        imgs += "<img src='img/pic" + i + ".jpg'>";
        // 변수 imgs에 대입 연산자를 이용하여 다음의 태그를 계속해서 10개가 될 때까지 추가
    };

    $("section").html(imgs);
    // html() 구문에 조금 전 태그를 반복하며 생성해둔 변수 imgs를 넣어 다시 section 영역에 추가

    $("body").on("mousemove", function(e) {
        const wid=$(window).width();
        const posX=e.pageX;

        const percent=Math.floor((posX/wid)*10);
        // 변수 percent에 10까지의 백분율 수치 저장
        // Math.floor(); 함수를 사용하면 소수점 이하를 버림

        $("section > img").hide();
        $("section > img").eq(percent).show();
    });
});