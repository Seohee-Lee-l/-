$(function() {
    $("article ul li").on("click", function() {
        let num=$(this).index();
        // console.log(num);

        $("article ul li").removeClass("on");
        $(this).addClass("on");

        $(".slide-box").css("transform", "translateY("+(num*-700)+"px)");
    });


    // 서브메뉴 클릭 시 폼 화면 열리기
    $(".submenu ul li").eq(0).click(function() {
        $(".onlineQna").fadeIn(500);
    });

    $(".span-btn").eq(0).click(function() {
        $(".onlineQna").fadeIn(500);
    });

    $(".cancleBtn").on("click", function() {
        $(".onlineQna").hide();
        $("input").val('');
        $("input[name=human]").prop("checked", false);
        $("#where").val('');
        // $("input[type=checkbox]").val('') >> 해당 요소의 checked 속성을 false로 설정해서 체크를 해제

        const checkbox=document.getElementById("input-checkbox1");
        checkbox.checked=false;

        const checkbox1=document.getElementById("input-checkbox2");
        checkbox1.checked=false;
    });



    // 시계
    setInterval(displayNow, 1000);

    function displayNow() {
        const date=new Date();
        const hours=date.getHours();
        const minutes=date.getMinutes();
        const seconds=date.getSeconds();

        let h, m, s;

        if (hours<10) {
            h="0"+hours;
        } else {
            h=hours;
        }

        if (minutes<10) {
            m="0"+minutes;
        } else {
            m=minutes;
        }

        if (seconds<10) {
            s="0"+seconds;
        } else {
            s=seconds;
        }


        $(".tt span").eq(0).text(h);
        $(".tt span").eq(1).text(m);
        $(".tt span").eq(2).text(s);
    };
});