$(function() {
    const numAc=$("article").size();
    const widSec=200*numAc;
    const widTotal=widSec+600;

    $("section").width(widTotal);
    // $("body").width(widSec);

    $(window).on("scroll", function() {
        const scroll=$(this).scrollTop();
        $("section").stop().animate({"left": -scroll}, 600);
    });

    $("article h2").on("click", function(e) {
        e.preventDefault();

        const index=$(this).parent().index();
        const src=$(this).children("a").attr("href");
        const posAc=200*index;

        $("article").removeClass("on");
        $(this).parent().addClass("on");

        $("article p img").attr({"src":""});
        // 모든 article의 p > img의 src를 빈 값으로 초기화
        $(this).siblings("p").children("img").attr({"src":src});
        // 클릭한 h2의 형제 요소인 p > img의 src를 변수 src값으로 변경
        $('html, body').scrollTop(posAc);
    });

    // 닫기 버튼 클릭시
    $("span").on("click", function() {
        $("article").removeClass("on");
    });


    // 네비게이션 클릭 시 5장씩 이동
    $("#navi li").on("click", function() {
        const i=$(this).index();
        const posNavi=1000*i;
        // 200(article의 width)*5=1000

        $("#navi li, article").removeClass();
        $(this).addClass("on");
        $("html, body").scrollTop(posNavi);
    });
});