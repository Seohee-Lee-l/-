function Contact() {
    return (
        <main style={{padding: '20px'}}>
            <h2>Contact Page</h2>
            <p>이 페이지에서는 연락처 정보를 보여줍니다.</p>

            <img src='img/mpr3.png' alt='banner' style={{width: '100%', height: 'auto', borderRadius: '8px'}}/>
            <img src='img/mpr1.png' alt='banner' style={{width: '100%', height: 'auto', borderRadius: '8px'}}/>
        </main>
    );
}
window.Contact=Contact;