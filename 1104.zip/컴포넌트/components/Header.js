function Header() {
    return (
        <header style={{padding: '20px', backgroundColor: '#282c34', color: 'white'}}>
            <h1>
                <a href='index.html' style={{color: 'white', textDecoration: 'none'}}>
                    My Website
                </a>
            </h1>
        </header>
    );
}
window.Header=Header;
// 외부 js로 로드할 수 있게 window 등록