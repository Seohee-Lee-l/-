function About() {
    return (
        <main style={{padding: '20px'}}>
            <h2>About Page</h2>
            <p>React Router + CDN 환경 예제입니다.</p>

            {/* 이미지 배너 */}
            <div style={{marginTop: '20px'}}>
                <img src='img/mpr1.png' alt='banner' style={{width: '100%', height: 'auto', borderRadius: '8px'}}/>
            </div>
        </main>
    );
}
window.About=About;