function Home() {
    return (
        <main style={{padding: '20px'}}>
            <h2>Home Page</h2>
            <p>이 앱은 CDN으로만 구성된 React Router 예제입니다.</p>

            <img src='img/mpr2.png' alt='banner' style={{width: '100%', height: 'auto', borderRadius: '8px'}}/>
        </main>
    );
}
window.Home=Home;