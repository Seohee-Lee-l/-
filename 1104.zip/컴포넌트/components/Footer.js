function Footer() {
    return (
        <footer style={{padding: '20px', backgroundColor: '#282c34', color: 'white'}}>
            <img src='img/mpr2.png' alt='banner' style={{width: '100%', height: 'auto', borderRadius: '8px'}}/>
            <p>Footer Content &copy; 2025</p>
        </footer>
    );
}
window.Footer=Footer;