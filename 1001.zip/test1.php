<?php
    $connect=mysqli_connect("localhost", "sag1880", "seo30513!!", "sag1880") or die ("SQL server에 연결할 수 없습니다.");

    $sql="SELECT * FROM exam";
    $result=mysqli_query($connect, $sql);
    /*
        $connect라는 데이터베이스 연결을 통해 $sql에 저장된 SQL 쿼리를 실행하고, 
        그 결과를 $result 변수에 저장
    */

    if ($result) {
        // 연관, 숫자(인덱스) 배열 모두 가져옴
        while ($row=mysqli_fetch_array($result)) {
            echo "ID: ".$row['id']."<br>";
            echo "이름: ".$row['name']."<br>";
            echo "나이: ".$row['age']."<br><br>";
        }
    } else {
        echo "쿼리 실패: ".mysqli_error($connect);
    }

    // 데이터베이스 연결 종료
    mysqli_close($connect);
?>