<?php
//$connect=mysqli_connect("호스트","DB아아디","DB비밀번호","DB명")
$connect=mysqli_connect("localhost","DB아아디","DB비밀번호","DB명") or
            die( "SQL server에 연결할 수 없습니다."); 

    $sql = "SELECT * FROM exam";   
    $result = mysqli_query($connect,$sql);   
/*
$connect라는 데이터베이스 연결을 통해 $sql에 저장된 SQL 쿼리를 실행하고,
 그 결과를 $result 변수에 저장
*/   
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "ID: " . $row['id'] . "<br>";
        echo "이름: " . $row['name'] . "<br>";
        echo "나이: " . $row['age'] . "<br><br>";
    }
} else {
    echo "쿼리 실패: " . mysqli_error($connect);
}
// 4. 연결 종료
mysqli_close($connect); 
?>