create table exam(
	id varchar(4),
	name varchar(12),
	age int,
	primary key(id)
);