$(function() {
	const $mainImage=$("#main_image");
	const $ul=$mainImage.find("ul");
	const $imgs=$ul.find("li");
	const $prevBtn=$(".prev");
	const $nextBtn=$(".next");
	const $bookRollImgs=$("#book_roll img");

	let currentIndex=0;
	const totalSlides=$imgs.length;
	let autoSlideInterval;



	// slideTo() 함수
	function slideTo(index) {
		if (index < 0) index=0;
		if (index>=totalSlides) index=totalSlides-1;

		const slideWidth=$mainImage.width();
		$ul.css({
			"transition": "left 0.5s",
			"position": "relative",
			"left": -(slideWidth*index)+"px"
		});

		currentIndex=index;
		updateIndicators();
	};


	// updateIndicators() 함수
	function updateIndicators() {
		$bookRollImgs.each(function(i) {
			const imgSrc=(i===currentIndex) ? "image/state_over.png" : "image/state_out.png";
			$(this).attr("src", imgSrc);
		});
	};


	// startAutoSlide() 함수
	function startAutoSlide() {
		autoSlideInterval=setInterval(function() {
			let nextIndex=currentIndex+1;
			if (nextIndex>=totalSlides) {
				nextIndex=0;
			}
			slideTo(nextIndex);
		}, 3000);
	};


	// stopAutoSlide() 함수
	function stopAutoSlide() {
		clearInterval(autoSlideInterval);
	};
	// 화살표 누르는 동안 auto 슬라이드 멈추는 용도


	// setEventListeners() 함수
	function setEventListeners() {
		$prevBtn.on("click", function(e) {
			e.preventDefault();

			stopAutoSlide();
			slideTo(currentIndex-1);
			startAutoSlide();
		});

		$nextBtn.on("click", function(e) {
			e.preventDefault();

			stopAutoSlide();
			slideTo(currentIndex+1);
			startAutoSlide();
		});


		$("#book_roll li a").each(function(index) {
			$(this).on("click", function(e) {
				e.preventDefault();

				stopAutoSlide();
				slideTo(index);
				startAutoSlide();
			});
		});


		// 윈도우 리사이즈
		$(window).on("resize", function() {
			slideTo(currentIndex);
		});
	};


	
	// 초기화
	slideTo(0);
	startAutoSlide();
	setEventListeners();
});
