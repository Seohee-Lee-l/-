$(function() {
    $(".t1 a, .t2 a").bind("focus click", function(e) {
        e.preventDefault();

        $(".item1, .item2").hide();
        $(this).parent().next().show();

        $("#newbooks-news h2 img").each(function() {
            $(this).attr("src", $(this).attr("src").replace("_over.gif", ".gif"));
        });

        $btnImg=$(this).children("img");
        $btnImg.attr("src", $btnImg.attr("src").replace(".gif", "_over.gif"));
    });
});



// $(function() {
//     $(".t1 a, .t2 a").bind("focus click",function(e) {
//         e.preventDefault();   /*a 속성으로 가는 것을 차단*/
//         $(".item1, .item2").hide();
//         $(this).parent().next().show();
// $("#newbooks-news h2 img").each(function(){
//   $(this).attr("src",$(this).attr("src").replace("_over.gif",".gif"));
//   });  

//  /*  2개의 탭버튼 이미지에 각각 접근하여 이미지의 src 속성에
//  '_over.gif'라는 문자가 있으면 '.gif'로 바꾼 뒤 src 속성으로 다시 적용하여 
//  모두 흑백으로  만듬.  
//  each(반복 제이쿼리 객체 수 만큼 반복 작업을 하는 함수*/	
  
//    $btnImg=$(this).children("img");
//    $btnImg.attr("src",$btnImg.attr("src").replace(".gif","_over.gif"));
//     });

// /*클릭한 탭 버튼 이미지의 src 속성 중 '.gif' 라는 문자열을 '_over.gif' 로 
// 바꾸어 src 속성에 다시 적용하여 활성화된 이미지로 변환시킴*/    

// });