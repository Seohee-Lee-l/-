﻿$(function() {
    $("#search_trigger").click(function() {
        $("#search_input").toggleClass("search_input_open")
        $(".form_search_input").val('');
        // 써놓은 거 없애기
        $(".form_search_input").focus();
        // 커서 깜빡이
    });
});