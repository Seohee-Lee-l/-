$(function() {
    const tagged={};

    $("#gallery img").each(function() {
        const img=this;
        // 현재 이미지 요소

        const tags=$(this).data("tags");

        if (tags) {
            tags.split(',').forEach(function(tagName) {
                if (tagged[tagName]==null) {
                    tagged[tagName]=[];
                }
                tagged[tagName].push(img);
            });
        }
        // 각 이미지 요소에 대해 data-tags 속성의 값을 가져와서
        // 쉼표(,)로 구분된 태그들을 배열로 만듦
        // 각 태그에 대해 tagged 객체에 해당 태그가 없으면 빈 배열을 생성하고
        // 해당 태그에 현재 이미지 요소를 추가
    });
    // .each() 종료


    


    $.each(tagged, function(tagName) {
        $("select").on("change", function() {
            const aa=$(this).val();

            if (aa=="") {
                $("#gallery img").show();
            } else {
                $("#gallery img").hide().filter(tagged[aa]).show();
            }
        });
    });
});