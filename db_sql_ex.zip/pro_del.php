<?php
    include "dbconn.php";

    $code=$_GET['code'];

    $sql="delete from product where code='$code'";
    mysqli_query($connect, $sql);
    mysqli_close($connect);

    Header("Location:pro_list.php");
    // 삭제 후 목록 페이지로 이동
?>