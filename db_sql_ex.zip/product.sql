create table product (
    code varchar(5),
    proname varchar(12),
    gu varchar(1),
    su int,
    dan int,
    price int,
    primary key(code)
);