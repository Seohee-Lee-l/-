<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        tr, td {
            text-align: center;
            border: none;
        }

        table {
            padding: 20px;
            box-sizing: border-box;
        }

        .tb {
            border: none;
        }
    </style>
</head>

<body>
    <h3>입력하기</h3>

    <form action="insert.php" method='post'>
        <table width='900' border='1'>
            <tr>
                <td>제품코드 : <input type="text" size='6' name='code'></td>
                <td>제품명 : <input type="text" size='6' name='proname'></td>
                <td>구분 : <input type="text" size='6' name='gu'></td>
                <td>수량 : <input type="text" size='6' name='su'></td>
                <td>단가 : <input type="text" size='6' name='dan'></td>
                <td><input type="submit" value='입력하기'></td>
            </tr>
        </table>
    </form>

    <div>
        <h3>성적 출력하기</h3>

        <p>
            <a href="pro_list.php?mode=big_first">[제품코드 내림차순정렬]</a>
            <a href="pro_list.php?mode=small_first">[제품코드 오름차순 정렬]</a>
            <!-- 
                ? : mode 변수를 GET 방식으로 받음
            -->
        </p>
    </div>

    <table width='900' border='1'>
        <tr>
            <td>제품코드</td>
            <td>제품명</td>
            <td>구분</td>
            <td>수량</td>
            <td>단가</td>
            <td>금액</td>
            <td>DEL</td>
        </tr>


        <!-- php 삽입 -->
        <!-- 오름차순 내림차순 -->
        <?php
            include "dbconn.php";
            // 데이터베이스 연결

            $mode=$_GET['mode'];
            // 변수 mode에 get방식으로 넘어온 값 저장

            $code=$_POST['code'];
            $proname=$_POST['proname'];
            $gu=$_POST['gu'];
            $su=$_POST['su'];
            $dan=$_POST['dan'];            
            
            if ($mode=="big_first")
                $sql="select * from product order by code desc";
            else if ($mode=="small_first")
                $sql="select * from product order by code";
            else
                $sql="select * from product";

            $result=mysqli_query($connect, $sql);
            // DB에 쿼리 전송
            // 생성된 SQL 쿼리를 데이터베이스에 전송하고 결과를 $result에 저장

            // DB 데이터 출력 시작
            while ($row=mysqli_fetch_array($result)) {
                $code=$row['code'];
                // $row 배열에서 code 항목을 $code 변수에 저장

                echo "
                    <tr>
                        <td> $row[code] </td>
                        <td> $row[proname] </td>
                        <td> $row[gu] </td>
                        <td> $row[su] </td>
                        <td> $row[dan] </td>
                        <td> $row[price] </td>

                        <td><a href='pro_del.php?code=$code'>[삭제]</a></td>
                    </tr>
                ";
            }

            mysqli_close($connect);
            // DB 연결 종료
        ?>
    </table>
</body>

</html>