<meta charset="UTF-8">

<?php
    include "dbconn.php";
    // DB 접속

    $code=$_POST['code'];
    $proname=$_POST['proname'];
    $gu=$_POST['gu'];
    $su=$_POST['su'];
    $dan=$_POST['dan'];
    // 폼에서 입력된 값 받기

    $rate=0.1;

    if ($gu=="2") {
        $price=($su*$dan)-($su*$dan*$rate);
    } else {
        $price=$su*$dan;
    }

    $sql="insert into product(code, proname, gu, su, dan, price) values";
    $sql.="('$code', '$proname', '$gu', '$su', '$dan', '$price')";

    $result=mysqli_query($connect, $sql);

    mysqli_close($connect);

    echo "
        <script>
            location.href='pro_list.php';
        </script>
    ";
    // 입력 후 목록 페이지로 이동
?>