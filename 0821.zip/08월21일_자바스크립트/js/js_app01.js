const bigPic = document.querySelector("#cup"); 
const smallPics = document.querySelectorAll(".small"); 
for(let i=0; i<smallPics.length; i++) {
    smallPics[i].addEventListener("click", function(){
        const newPic = this.src;
        bigPic.setAttribute("src", newPic); 
    });

}

/*
문서객체.setAttribute(속성이름, 값)  :  특정 속성에 값을 지정한다
문서객체.getAttribute(속성이름, 값)  :  특정 속성을 추출한다
*/
/*
[forEach]
const bigPic = document.querySelector("#cup");
const smallPics = document.querySelectorAll(".small");

smallPics.forEach(function(smallPic) {
  smallPic.addEventListener("click", function() {
    const newPic = this.src;
    bigPic.setAttribute("src", newPic);
  });
});
*/