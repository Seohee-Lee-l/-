const bigPic=document.querySelector("#cup");
const smallPics=document.querySelectorAll(".small");

// for (let i=0; i<smallPics.length; i++) {
//     smallPics[i].addEventListener('click', function() {
//         const newPic=this.src;
//         // this >> 현재 선택한 요소를 말함
//         // 현재 선택한 경로(src)를 newPic에 집어 넣음
//         bigPic.setAttribute("src", newPic);
//         // bigPic의 경로를 newPic으로 바꿈
//     });
// };

smallPics.forEach(function(small) {
    small.addEventListener('click', function() {
        const newPic=this.src;
        bigPic.setAttribute("src", newPic);
    });
});