$(function() {
    $("a[href*=#]").on("click", function(e) {
        // href 속성에 #이 포함된 모든 <a>태그를 선택
        e.preventDefault();

        $("html, body").animate({
            scrollTop:$($(this).attr("href")).offset().top
        }, 500, "linear");
    });
});