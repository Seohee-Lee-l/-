$(function() {
    const imgItems=$(".slider li").length;
    let imgPos=1;

    for (let i=1; i<=imgItems; i++) {
        $(".pagination").append("<li><span>●</span></li>");
    }
    $(".slider li").hide();

    $(".slider li:first").show();
    $(".pagination li:first").css({"color": "#000"});

    $(".pagination li").click(pagination);
    $(".left").click(prevSlider);
    $(".right").click(nextSlider);

    // pagination() 함수 (인디케이터 클릭 시 이미지 변경)
    function pagination() {
        const paginationPos=$(this).index()+1;
        $(".slider li").hide();
        $(".slider li:nth-child("+paginationPos+")").fadeIn();
        $(".pagination li").css({"color" : "#ddd"});
        $(".pagination li:nth-child("+paginationPos+")").css({"color": "#000"});
        imgPos=paginationPos;
    };


    // nextSlider() 함수
    function nextSlider() {
        if (imgPos>=imgItems) {
            imgPos=1;
        } else {imgPos++;}

        $(".slider li").hide();
        $(".slider li:nth-child("+imgPos+")").fadeIn();

        $(".pagination li").css({"color" : "#ddd"});
        $(".pagination li:nth-child("+imgPos+")").css({"color": "#000"});
    };


    // prevSlider() 함수
    function prevSlider() {
        if (imgPos<=1) {
            imgPos=imgItems;
        } else {
            imgPos--;
        }

        $(".slider li").hide();
        $(".slider li:nth-child("+imgPos+")").fadeIn();

        $(".pagination li").css({"color" : "#ddd"});
        $(".pagination li:nth-child("+imgPos+")").css({"color": "#000"});
    };


    // 자동 슬라이드
    setInterval(function() {
        nextSlider();
    }, 4000);
});