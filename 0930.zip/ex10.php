<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
        $a=85;

        if ($a>=90)
        echo "$a : 최우수";

        elseif ($a>=80)
        echo "$a : 우수";

        else
        echo "$a : 노력";
    ?>
</body>

</html>