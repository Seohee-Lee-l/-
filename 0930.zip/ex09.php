<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
        $pilgi=95;
        $silgi=55;
        $result='합격';

        // ||(or)
        if ($pilgi<70 || $silgi<80) {
            $result='불합격';
        }

        echo "필기 점수 : $pilgi / 실기 점수 : $silgi <br>";
        echo "결과 : $result";
    ?>
</body>

</html>