<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        table {
            width: 600px;
        }

        table tr {
            border-color: #ccc;
            text-align: center;
        }
    </style>
</head>

<body>
    <?php
        // $arr=array("a", "b", "c", "d", "e");
        $arr=["a", "b", "c", "d", "e"];

        echo $arr[0].", ".$arr[1].", ".$arr[2]." and ".$arr[3].", ".$arr[4];
    ?>
</body>

</html>