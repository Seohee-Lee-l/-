<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
        // $num=80; 2로 나눈 나머지가 0과 같으면 짝수, 아니면 홀수
        $num=80;

        if ($num%2==0) {
            echo "$num: 짝수";
        } else {
            echo "$num: 홀수";
        }
    ?>
</body>

</html>