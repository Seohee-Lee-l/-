<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php 
        $a=5;
        $a+=3;
        echo $a."<br>";

        $a-=4;
        echo $a."<br>";

        $a*=2;
        echo $a."<br>";

        $a/=4;
        echo $a."<br>";

        $a%=2;
        echo $a."<br>";

        $a="오렌지";
        $a.=" 주스";
        echo $a."<br>";
    ?>
</body>

</html>