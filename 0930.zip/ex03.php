<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php 
        $a=3;
        $b=2;

        $a=$a+$b;
        $b=$a+5;
        $c=$a*$b;

        $c=$c%2;
        $a=$b+$c;
        $b=$a*$b;

        echo "a: $a <br> b: $b <br> c: $c";
    ?>
</body>

</html>