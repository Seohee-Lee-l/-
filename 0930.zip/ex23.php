<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        table {
            width: 600px;
        }

        table tr {
            border-color: #ccc;
            text-align: center;
        }
    </style>
</head>

<body>
    <?php
        function plus($a, $b) {
            $c=$a+$b;

            return $c;
        }

        $result=plus(15, 25);
        echo $result."<br>";

        $result=plus(3500, 1500);
        echo $result;
    ?>
</body>

</html>