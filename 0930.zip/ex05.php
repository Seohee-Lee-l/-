<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php 
        $n1="010";
        $n2="2322";
        $n3="3233";

        $hp=$n1."-".$n2."-".$n3;
        echo "휴대폰 번호 : $hp";

        // 문자열 연결 (dot 연산자 .)
        // +- -- /- %=
        // &&(and) ||(or)
    ?>
</body>

</html>