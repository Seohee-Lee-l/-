<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        table {
            width: 600px;
        }

        table tr {
            border-color: #ccc;
            text-align: center;
        }
    </style>
</head>

<body>
    <h3>구구단표</h3>

    <table border='1'>
        <tr>
            <td>2단</td>
            <td>3단</td>
            <td>4단</td>
            <td>5단</td>
            <td>6단</td>
            <td>7단</td>
            <td>8단</td>
            <td>9단</td>
        </tr>

        <?php
            for ($b=1; $b<=9; $b++) {
                echo "<tr>";

                for ($a=2; $a<=9; $a++) {
                    $c=$a*$b;
                    echo "<td>{$a}X{$b}=$c</td>";
                }

                echo "</tr>";
            }
        ?>
    </table>
    
</body>

</html>