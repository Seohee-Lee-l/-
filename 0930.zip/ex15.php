<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $num=0;
    for ($a=1; $a<=10; $a++) {
        $num+=$a;
    }

    echo ("1에서 10까지의 자연수의 합은 $num 입니다. <br>");
    ?>
</body>

</html>