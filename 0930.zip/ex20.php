<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        table {
            width: 600px;
        }

        table tr {
            border-color: #ccc;
            text-align: center;
        }
    </style>
</head>

<body>
    <?php
        // count(): 배열의 길이 (요소의 개수)를 반환하는 함수
        $arr=array("a", "b", "c", "d", "e");

        for ($i=0; $i<count($arr); $i++) {
            echo $arr[$i]."<br>";
        }
    ?>
</body>

</html>