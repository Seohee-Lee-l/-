<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
        /* 
            90점 이상 A / 80 이상 B / 70 이상 C / 60 이상 D / 나머지 F
        */
        $a=85;

        if ($a>=90) {
            echo "$a ==> A";
        } elseif ($a>=80) {
            echo "$a ==> B";
        } elseif ($a>=70) {
            echo "$a ==> C";
        } elseif ($a>=60) {
            echo "$a ==> D";
        } else {
            echo "$a ==> F";
        }
    ?>
</body>

</html>