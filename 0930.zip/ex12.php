<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
        $i=100;

        do {
            echo $i."<br>";
        } while ($i<=10);

        // do-while문은 조건 검사 전에 한 번은 무조건 실행
        // 조건이 뒤에 나오기 때문에
    ?>
</body>

</html>