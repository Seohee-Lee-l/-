<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
        // count(): 배열의 길이 (요소의 개수)를 반환하는 함수
        // foreach ($배열 as $값) {}
        $arr=["a", "b", "c", "d", "e"];

        foreach ($arr as $val) {
            echo $val."<br>";
        }
    ?>
</body>

</html>