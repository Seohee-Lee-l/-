<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        table {
            width: 600px;
        }

        table tr {
            border-color: #ccc;
            text-align: center;
        }
    </style>
</head>

<body>
    <?php
        $tel="010-2777-3333";
        $num_tel=strlen($tel);
        // strlen(): 문자열의 길이(문자 수)를 반환하는 함수
        echo "strlen() 함수 사용 : $num_tel <br>";

        $tel1=substr($tel, 0, 3);
        $tel2=substr($tel, 4, 4);
        $tel3=substr($tel, 9, 4);
        echo "substr() 함수 사용 : $tel1 $tel2 $tel3 <br>";

        $phone=explode("-", $tel);
        echo "explode() 함수 사용 : $phone[0] $phone[1] $phone[2] <br>";
        // explode(): 문자열을 특정 구분자로 나누어 배열로 반환하는 함수
        // explode(구분자, 문자열)
    ?>
</body>

</html>