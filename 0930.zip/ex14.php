<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        table {
            width: 600px;
        }

        table tr {
            width: 50px;
            border-color: #ccc;
            text-align: center;
        }

        td {
            width: 80px;
        }

        .a50 {
            width: 50px;
        }
    </style>
</head>

<body>
    <h3>게시판 목록보기</h3>
    <table border='1'>
        <tr>
            <td>번호</td>
            <td>제목</td>
            <td>글쓴이</td>
            <td>날짜</td>
        </tr>

        <?php
        $num=1;
        $name='홍길동';
        $date='2024/03/10';

        for ($i=1; $i<=10; $i++) {
            $title="게시판 제목".$num;
            echo "<tr>
                    <td>$num</td>
                    <td>$title</td>
                    <td class='a50'>$name</td>
                    <td>$date</td>
                </tr>";
            $num++;
        }
        ?>
    </table>
</body>

</html>