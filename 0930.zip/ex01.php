<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php 
        # 한 줄 주석
        // 한 줄 주석
        /*
            여러 줄 주석
            여러 줄 주석
            여러 줄 주석
        */

        echo '<p>안녕하세요!</p>';
    ?>
</body>

</html>