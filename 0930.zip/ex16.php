<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
        for ($a=2; $a<=9; $a++) {
            for ($b=1; $b<=9; $b++) {
                $c=$a*$b;

                echo ("$a x $b = $c <br>");
            }

            echo ("------------------- <br>");
        }
    ?>
</body>

</html>