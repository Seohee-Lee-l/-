<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php 
        $a=7;
        $b=8;

        $a++;
        // ++는 후위 증가 연산자, 먼저 값을 사용하고 나중에 값을 증가
        $b--;
        // --는 후위 감소 연산자, 먼저 값을 사용하고 나중에 값을 감소시킴

        $b=$a*$b+2;
        $c=$a+$b;

        echo "a: $a, b: $b, c: $c <br>";
        // a=8 b=58 c=66
    ?>
</body>

</html>